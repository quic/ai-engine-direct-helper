## Q & A

1. If you encounter a certificate problem, like the following log:
```
  ⠄ default:win-64       [00:00:01] resolving pypi dependencies
  Error:   x failed to solve the pypi requirements of 'default' 'win-64'
    |-> failed to resolve pypi dependencies
    |-> Failed to fetch: `https://pypi.org/simple/requests/`
    |-> Request failed after 3 retries
    |-> error sending request for url (https://pypi.org/simple/requests/)
    |-> client error (Connect)
    `-> invalid peer certificate: UnknownIssuer
```

You can run the following command:
```pwsh
pixi config edit
```
Then add the following lines to the opened configuration file, remember to save the file:
```toml
tls-no-verify = true

[pypi-config]
allow-insecure-host = ["*"]
```
